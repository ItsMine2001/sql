---

### Relational Database Schema

#### Tables:
1. *Users*
    - user_id (Primary Key)
    - username
    - password
    - email
    - created_at
    - updated_at

2. *Hotels*
    - hotel_id (Primary Key)
    - hotel_name
    - location
    - rating
    - created_at
    - updated_at

3. *Rooms*
    - room_id (Primary Key)
    - hotel_id (Foreign Key)
    - room_number
    - room_type
    - price
    - availability (boolean)
    - created_at
    - updated_at

4. *Reservations*
    - reservation_id (Primary Key)
    - user_id (Foreign Key)
    - room_id (Foreign Key)
    - check_in_date
    - check_out_date
    - status
    - created_at
    - updated_at

5. *Bills*
    - bill_id (Primary Key)
    - reservation_id (Foreign Key)
    - total_amount
    - payment_status
    - created_at
    - updated_at

#### Stored Procedures:

1. *Check Room Availability*
    sql
    CREATE PROCEDURE CheckRoomAvailability(
        IN hotel_id INT,
        IN check_in_date DATE,
        IN check_out_date DATE
    )
    BEGIN
        SELECT room_id, room_number, room_type, price
        FROM Rooms
        WHERE hotel_id = hotel_id
        AND room_id NOT IN (
            SELECT room_id 
            FROM Reservations 
            WHERE (check_in_date BETWEEN check_in_date AND check_out_date)
            OR (check_out_date BETWEEN check_in_date AND check_out_date)
        )
        AND availability = TRUE;
    END;
    

2. *User Login*
    sql
    CREATE PROCEDURE UserLogin(
        IN username VARCHAR(255),
        IN password VARCHAR(255)
    )
    BEGIN
        SELECT user_id, username, email
        FROM Users
        WHERE username = username AND password = password;
    END;
    

3. *Register Room*
    sql
    CREATE PROCEDURE RegisterRoom(
        IN hotel_id INT,
        IN room_number VARCHAR(255),
        IN room_type VARCHAR(255),
        IN price DECIMAL(10, 2)
    )
    BEGIN
        INSERT INTO Rooms (hotel_id, room_number, room_type, price, availability, created_at, updated_at)
        VALUES (hotel_id, room_number, room_type, price, TRUE, NOW(), NOW());
    END;
    

4. *Register Hotel*
    sql
    CREATE PROCEDURE RegisterHotel(
        IN hotel_name VARCHAR(255),
        IN location VARCHAR(255),
        IN rating INT
    )
    BEGIN
        INSERT INTO Hotels (hotel_name, location, rating, created_at, updated_at)
        VALUES (hotel_name, location, rating, NOW(), NOW());
    END;
    

5. *Generate Bill*
    sql
    CREATE PROCEDURE GenerateBill(
        IN reservation_id INT,
        IN total_amount DECIMAL(10, 2),
        IN payment_status VARCHAR(50)
    )
    BEGIN
        INSERT INTO Bills (reservation_id, total_amount, payment_status, created_at, updated_at)
        VALUES (reservation_id, total_amount, payment_status, NOW(), NOW());
    END;
    

6. *Check-In Maintenance*
    sql
    CREATE PROCEDURE CheckIn(
        IN reservation_id INT
    )
    BEGIN
        UPDATE Reservations
        SET status = 'Checked In', updated_at = NOW()
        WHERE reservation_id = reservation_id;
    END;
    

7. *Check-Out Maintenance*
    sql
    CREATE PROCEDURE CheckOut(
        IN reservation_id INT
    )
    BEGIN
        UPDATE Reservations
        SET status = 'Checked Out', updated_at = NOW()
        WHERE reservation_id = reservation_id;
    END;
    

### Integration and Testing:
- Work with database and frontend teams to ensure seamless integration.
- Conduct thorough testing to validate the correctness and reliability of the implemented features.